# Motion Studio

A Vite + React + TypeScript project scaffold for a motion-design workspace.

## Getting started

```bash
npm install
npm run dev
```

## Structure

The workspace includes the requested layered architecture for the app shell, graph editor, animation core, adapters, storage, and clipboard modules.
